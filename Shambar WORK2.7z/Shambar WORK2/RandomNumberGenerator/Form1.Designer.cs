﻿namespace RandomNumberGenerator;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.labelTitle = new System.Windows.Forms.Label();
        this.labelMin = new System.Windows.Forms.Label();
        this.labelMax = new System.Windows.Forms.Label();
        this.textBoxMin = new System.Windows.Forms.TextBox();
        this.textBoxMax = new System.Windows.Forms.TextBox();
        this.buttonGenerate = new System.Windows.Forms.Button();
        this.labelResult = new System.Windows.Forms.Label();
        this.labelRangeInfo = new System.Windows.Forms.Label();
        this.SuspendLayout();
        // 
        // labelTitle
        // 
        this.labelTitle.AutoSize = true;
        this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.labelTitle.Location = new System.Drawing.Point(32, 16);
        this.labelTitle.Name = "labelTitle";
        this.labelTitle.Size = new System.Drawing.Size(318, 37);
        this.labelTitle.TabIndex = 0;
        this.labelTitle.Text = "Генератор случайных чисел";
        // 
        // labelMin
        // 
        this.labelMin.AutoSize = true;
        this.labelMin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelMin.Location = new System.Drawing.Point(32, 88);
        this.labelMin.Name = "labelMin";
        this.labelMin.Size = new System.Drawing.Size(164, 28);
        this.labelMin.TabIndex = 1;
        this.labelMin.Text = "Минимальное:";
        // 
        // labelMax
        // 
        this.labelMax.AutoSize = true;
        this.labelMax.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelMax.Location = new System.Drawing.Point(32, 136);
        this.labelMax.Name = "labelMax";
        this.labelMax.Size = new System.Drawing.Size(171, 28);
        this.labelMax.TabIndex = 2;
        this.labelMax.Text = "Максимальное:";
        // 
        // textBoxMin
        // 
        this.textBoxMin.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.textBoxMin.Location = new System.Drawing.Point(224, 80);
        this.textBoxMin.Name = "textBoxMin";
        this.textBoxMin.Size = new System.Drawing.Size(240, 39);
        this.textBoxMin.TabIndex = 3;
        this.textBoxMin.Text = "1";
        // 
        // textBoxMax
        // 
        this.textBoxMax.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.textBoxMax.Location = new System.Drawing.Point(224, 128);
        this.textBoxMax.Name = "textBoxMax";
        this.textBoxMax.Size = new System.Drawing.Size(240, 39);
        this.textBoxMax.TabIndex = 4;
        this.textBoxMax.Text = "100";
        // 
        // buttonGenerate
        // 
        this.buttonGenerate.BackColor = System.Drawing.Color.LightGreen;
        this.buttonGenerate.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonGenerate.Location = new System.Drawing.Point(32, 208);
        this.buttonGenerate.Name = "buttonGenerate";
        this.buttonGenerate.Size = new System.Drawing.Size(432, 60);
        this.buttonGenerate.TabIndex = 5;
        this.buttonGenerate.Text = "Сгенерировать число";
        this.buttonGenerate.UseVisualStyleBackColor = false;
        this.buttonGenerate.Click += new System.EventHandler(this.buttonGenerate_Click);
        // 
        // labelResult
        // 
        this.labelResult.BackColor = System.Drawing.Color.LightYellow;
        this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.labelResult.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.labelResult.Location = new System.Drawing.Point(32, 304);
        this.labelResult.Name = "labelResult";
        this.labelResult.Size = new System.Drawing.Size(432, 80);
        this.labelResult.TabIndex = 6;
        this.labelResult.Text = "Нажмите кнопку для генерации";
        this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        // 
        // labelRangeInfo
        // 
        this.labelRangeInfo.AutoSize = true;
        this.labelRangeInfo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
        this.labelRangeInfo.ForeColor = System.Drawing.Color.Gray;
        this.labelRangeInfo.Location = new System.Drawing.Point(224, 168);
        this.labelRangeInfo.Name = "labelRangeInfo";
        this.labelRangeInfo.Size = new System.Drawing.Size(240, 23);
        this.labelRangeInfo.TabIndex = 7;
        this.labelRangeInfo.Text = "Введите диапазон (целые числа)";
        // 
        // Form1
        // 
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(500, 413);
        this.Controls.Add(this.labelRangeInfo);
        this.Controls.Add(this.labelResult);
        this.Controls.Add(this.buttonGenerate);
        this.Controls.Add(this.textBoxMax);
        this.Controls.Add(this.textBoxMin);
        this.Controls.Add(this.labelMax);
        this.Controls.Add(this.labelMin);
        this.Controls.Add(this.labelTitle);
        this.Name = "Form1";
        this.Text = "Генератор случайных чисел";
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label labelTitle;
    private System.Windows.Forms.Label labelMin;
    private System.Windows.Forms.Label labelMax;
    private System.Windows.Forms.TextBox textBoxMin;
    private System.Windows.Forms.TextBox textBoxMax;
    private System.Windows.Forms.Button buttonGenerate;
    private System.Windows.Forms.Label labelResult;
    private System.Windows.Forms.Label labelRangeInfo;
}