namespace RandomNumberGenerator;

public partial class Form1 : Form
{
    private Random random = new Random();

    public Form1()
    {
        InitializeComponent();
    }

    private void buttonGenerate_Click(object sender, EventArgs e)
    {
        // Проверка ввода
        if (!int.TryParse(textBoxMin.Text, out int min))
        {
            MessageBox.Show("Пожалуйста, введите корректное минимальное число!", 
                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            textBoxMin.Focus();
            return;
        }

        if (!int.TryParse(textBoxMax.Text, out int max))
        {
            MessageBox.Show("Пожалуйста, введите корректное максимальное число!", 
                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            textBoxMax.Focus();
            return;
        }

        // Проверка диапазона
        if (min > max)
        {
            MessageBox.Show("Минимальное значение не может быть больше максимального!", 
                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // Генерация случайного числа
        int randomNumber = random.Next(min, max + 1);
        
        // Отображение результата
        labelResult.Text = randomNumber.ToString();
        labelResult.ForeColor = Color.DarkBlue;
    }
}