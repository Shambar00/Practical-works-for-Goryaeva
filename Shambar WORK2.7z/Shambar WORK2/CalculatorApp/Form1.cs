namespace CalculatorApp;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private bool ValidateInput(out double num1, out double num2)
    {
        num1 = 0;
        num2 = 0;
        
        if (!double.TryParse(textBoxNum1.Text, out num1))
        {
            MessageBox.Show("Пожалуйста, введите корректное число в поле 'Число 1'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        
        if (!double.TryParse(textBoxNum2.Text, out num2))
        {
            MessageBox.Show("Пожалуйста, введите корректное число в поле 'Число 2'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        
        return true;
    }

    private bool ValidateSingleInput(out double num)
    {
        num = 0;
        
        if (!double.TryParse(textBoxNum1.Text, out num))
        {
            MessageBox.Show("Пожалуйста, введите корректное число в поле 'Число 1'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }
        
        return true;
    }

    private void DisplayResult(double result)
    {
        textBoxResult.Text = result.ToString("F6").TrimEnd('0').TrimEnd('.');
        if (textBoxResult.Text == "") textBoxResult.Text = "0";
    }

    // Базовые операции
    private void buttonAdd_Click(object sender, EventArgs e)
    {
        if (ValidateInput(out double num1, out double num2))
        {
            DisplayResult(num1 + num2);
        }
    }

    private void buttonSubtract_Click(object sender, EventArgs e)
    {
        if (ValidateInput(out double num1, out double num2))
        {
            DisplayResult(num1 - num2);
        }
    }

    private void buttonMultiply_Click(object sender, EventArgs e)
    {
        if (ValidateInput(out double num1, out double num2))
        {
            DisplayResult(num1 * num2);
        }
    }

    private void buttonDivide_Click(object sender, EventArgs e)
    {
        if (ValidateInput(out double num1, out double num2))
        {
            if (num2 == 0)
            {
                MessageBox.Show("Деление на ноль невозможно!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DisplayResult(num1 / num2);
        }
    }

    // Дополнительные операции
    private void buttonPower_Click(object sender, EventArgs e)
    {
        if (ValidateInput(out double num1, out double num2))
        {
            DisplayResult(Math.Pow(num1, num2));
        }
    }

    private void buttonSqrt_Click(object sender, EventArgs e)
    {
        if (ValidateSingleInput(out double num))
        {
            if (num < 0)
            {
                MessageBox.Show("Нельзя извлечь корень из отрицательного числа!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DisplayResult(Math.Sqrt(num));
        }
    }

    private void buttonModulo_Click(object sender, EventArgs e)
    {
        if (ValidateInput(out double num1, out double num2))
        {
            if (num2 == 0)
            {
                MessageBox.Show("Деление на ноль невозможно!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DisplayResult(num1 % num2);
        }
    }

    private void buttonAbs_Click(object sender, EventArgs e)
    {
        if (ValidateSingleInput(out double num))
        {
            DisplayResult(Math.Abs(num));
        }
    }

    private void buttonClear_Click(object sender, EventArgs e)
    {
        textBoxNum1.Clear();
        textBoxNum2.Clear();
        textBoxResult.Text = "0";
        textBoxNum1.Focus();
    }
}