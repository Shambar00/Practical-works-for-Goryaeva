﻿namespace CalculatorApp;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.textBoxResult = new System.Windows.Forms.TextBox();
        this.buttonAdd = new System.Windows.Forms.Button();
        this.buttonSubtract = new System.Windows.Forms.Button();
        this.buttonMultiply = new System.Windows.Forms.Button();
        this.buttonDivide = new System.Windows.Forms.Button();
        this.labelResult = new System.Windows.Forms.Label();
        this.textBoxNum1 = new System.Windows.Forms.TextBox();
        this.textBoxNum2 = new System.Windows.Forms.TextBox();
        this.labelNum1 = new System.Windows.Forms.Label();
        this.labelNum2 = new System.Windows.Forms.Label();
        this.buttonPower = new System.Windows.Forms.Button();
        this.buttonSqrt = new System.Windows.Forms.Button();
        this.buttonModulo = new System.Windows.Forms.Button();
        this.buttonAbs = new System.Windows.Forms.Button();
        this.buttonClear = new System.Windows.Forms.Button();
        this.SuspendLayout();
        // 
        // textBoxResult
        // 
        this.textBoxResult.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.textBoxResult.Location = new System.Drawing.Point(32, 180);
        this.textBoxResult.Name = "textBoxResult";
        this.textBoxResult.ReadOnly = true;
        this.textBoxResult.Size = new System.Drawing.Size(400, 39);
        this.textBoxResult.TabIndex = 0;
        this.textBoxResult.Text = "0";
        this.textBoxResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
        // 
        // buttonAdd
        // 
        this.buttonAdd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonAdd.Location = new System.Drawing.Point(32, 240);
        this.buttonAdd.Name = "buttonAdd";
        this.buttonAdd.Size = new System.Drawing.Size(90, 50);
        this.buttonAdd.TabIndex = 1;
        this.buttonAdd.Text = "+";
        this.buttonAdd.UseVisualStyleBackColor = true;
        this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
        // 
        // buttonSubtract
        // 
        this.buttonSubtract.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonSubtract.Location = new System.Drawing.Point(128, 240);
        this.buttonSubtract.Name = "buttonSubtract";
        this.buttonSubtract.Size = new System.Drawing.Size(90, 50);
        this.buttonSubtract.TabIndex = 2;
        this.buttonSubtract.Text = "-";
        this.buttonSubtract.UseVisualStyleBackColor = true;
        this.buttonSubtract.Click += new System.EventHandler(this.buttonSubtract_Click);
        // 
        // buttonMultiply
        // 
        this.buttonMultiply.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonMultiply.Location = new System.Drawing.Point(224, 240);
        this.buttonMultiply.Name = "buttonMultiply";
        this.buttonMultiply.Size = new System.Drawing.Size(90, 50);
        this.buttonMultiply.TabIndex = 3;
        this.buttonMultiply.Text = "×";
        this.buttonMultiply.UseVisualStyleBackColor = true;
        this.buttonMultiply.Click += new System.EventHandler(this.buttonMultiply_Click);
        // 
        // buttonDivide
        // 
        this.buttonDivide.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonDivide.Location = new System.Drawing.Point(320, 240);
        this.buttonDivide.Name = "buttonDivide";
        this.buttonDivide.Size = new System.Drawing.Size(90, 50);
        this.buttonDivide.TabIndex = 4;
        this.buttonDivide.Text = "÷";
        this.buttonDivide.UseVisualStyleBackColor = true;
        this.buttonDivide.Click += new System.EventHandler(this.buttonDivide_Click);
        // 
        // labelResult
        // 
        this.labelResult.AutoSize = true;
        this.labelResult.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelResult.Location = new System.Drawing.Point(32, 152);
        this.labelResult.Name = "labelResult";
        this.labelResult.Size = new System.Drawing.Size(99, 28);
        this.labelResult.TabIndex = 5;
        this.labelResult.Text = "Результат:";
        // 
        // textBoxNum1
        // 
        this.textBoxNum1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.textBoxNum1.Location = new System.Drawing.Point(32, 56);
        this.textBoxNum1.Name = "textBoxNum1";
        this.textBoxNum1.Size = new System.Drawing.Size(400, 34);
        this.textBoxNum1.TabIndex = 6;
        // 
        // textBoxNum2
        // 
        this.textBoxNum2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.textBoxNum2.Location = new System.Drawing.Point(32, 104);
        this.textBoxNum2.Name = "textBoxNum2";
        this.textBoxNum2.Size = new System.Drawing.Size(400, 34);
        this.textBoxNum2.TabIndex = 7;
        // 
        // labelNum1
        // 
        this.labelNum1.AutoSize = true;
        this.labelNum1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelNum1.Location = new System.Drawing.Point(32, 28);
        this.labelNum1.Name = "labelNum1";
        this.labelNum1.Size = new System.Drawing.Size(124, 28);
        this.labelNum1.TabIndex = 8;
        this.labelNum1.Text = "Число 1:";
        // 
        // labelNum2
        // 
        this.labelNum2.AutoSize = true;
        this.labelNum2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelNum2.Location = new System.Drawing.Point(32, 76);
        this.labelNum2.Name = "labelNum2";
        this.labelNum2.Size = new System.Drawing.Size(124, 28);
        this.labelNum2.TabIndex = 9;
        this.labelNum2.Text = "Число 2:";
        // 
        // buttonPower
        // 
        this.buttonPower.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonPower.Location = new System.Drawing.Point(32, 296);
        this.buttonPower.Name = "buttonPower";
        this.buttonPower.Size = new System.Drawing.Size(90, 50);
        this.buttonPower.TabIndex = 10;
        this.buttonPower.Text = "x²";
        this.buttonPower.UseVisualStyleBackColor = true;
        this.buttonPower.Click += new System.EventHandler(this.buttonPower_Click);
        // 
        // buttonSqrt
        // 
        this.buttonSqrt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonSqrt.Location = new System.Drawing.Point(128, 296);
        this.buttonSqrt.Name = "buttonSqrt";
        this.buttonSqrt.Size = new System.Drawing.Size(90, 50);
        this.buttonSqrt.TabIndex = 11;
        this.buttonSqrt.Text = "√";
        this.buttonSqrt.UseVisualStyleBackColor = true;
        this.buttonSqrt.Click += new System.EventHandler(this.buttonSqrt_Click);
        // 
        // buttonModulo
        // 
        this.buttonModulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonModulo.Location = new System.Drawing.Point(224, 296);
        this.buttonModulo.Name = "buttonModulo";
        this.buttonModulo.Size = new System.Drawing.Size(90, 50);
        this.buttonModulo.TabIndex = 12;
        this.buttonModulo.Text = "%";
        this.buttonModulo.UseVisualStyleBackColor = true;
        this.buttonModulo.Click += new System.EventHandler(this.buttonModulo_Click);
        // 
        // buttonAbs
        // 
        this.buttonAbs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonAbs.Location = new System.Drawing.Point(320, 296);
        this.buttonAbs.Name = "buttonAbs";
        this.buttonAbs.Size = new System.Drawing.Size(90, 50);
        this.buttonAbs.TabIndex = 13;
        this.buttonAbs.Text = "|x|";
        this.buttonAbs.UseVisualStyleBackColor = true;
        this.buttonAbs.Click += new System.EventHandler(this.buttonAbs_Click);
        // 
        // buttonClear
        // 
        this.buttonClear.BackColor = System.Drawing.Color.LightCoral;
        this.buttonClear.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonClear.Location = new System.Drawing.Point(32, 352);
        this.buttonClear.Name = "buttonClear";
        this.buttonClear.Size = new System.Drawing.Size(400, 40);
        this.buttonClear.TabIndex = 14;
        this.buttonClear.Text = "Очистить";
        this.buttonClear.UseVisualStyleBackColor = false;
        this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
        // 
        // Form1
        // 
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(482, 413);
        this.Controls.Add(this.buttonClear);
        this.Controls.Add(this.buttonAbs);
        this.Controls.Add(this.buttonModulo);
        this.Controls.Add(this.buttonSqrt);
        this.Controls.Add(this.buttonPower);
        this.Controls.Add(this.labelNum2);
        this.Controls.Add(this.labelNum1);
        this.Controls.Add(this.textBoxNum2);
        this.Controls.Add(this.textBoxNum1);
        this.Controls.Add(this.labelResult);
        this.Controls.Add(this.buttonDivide);
        this.Controls.Add(this.buttonMultiply);
        this.Controls.Add(this.buttonSubtract);
        this.Controls.Add(this.buttonAdd);
        this.Controls.Add(this.textBoxResult);
        this.Name = "Form1";
        this.Text = "Калькулятор";
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox textBoxResult;
    private System.Windows.Forms.Button buttonAdd;
    private System.Windows.Forms.Button buttonSubtract;
    private System.Windows.Forms.Button buttonMultiply;
    private System.Windows.Forms.Button buttonDivide;
    private System.Windows.Forms.Label labelResult;
    private System.Windows.Forms.TextBox textBoxNum1;
    private System.Windows.Forms.TextBox textBoxNum2;
    private System.Windows.Forms.Label labelNum1;
    private System.Windows.Forms.Label labelNum2;
    private System.Windows.Forms.Button buttonPower;
    private System.Windows.Forms.Button buttonSqrt;
    private System.Windows.Forms.Button buttonModulo;
    private System.Windows.Forms.Button buttonAbs;
    private System.Windows.Forms.Button buttonClear;
}