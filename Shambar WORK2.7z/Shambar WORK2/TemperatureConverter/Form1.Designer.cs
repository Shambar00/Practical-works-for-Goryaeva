﻿namespace TemperatureConverter;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.textBoxTemperature = new System.Windows.Forms.TextBox();
        this.comboBoxConversion = new System.Windows.Forms.ComboBox();
        this.buttonConvert = new System.Windows.Forms.Button();
        this.labelResult = new System.Windows.Forms.Label();
        this.labelTemperature = new System.Windows.Forms.Label();
        this.labelConversion = new System.Windows.Forms.Label();
        this.labelTitle = new System.Windows.Forms.Label();
        this.SuspendLayout();
        // 
        // textBoxTemperature
        // 
        this.textBoxTemperature.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.textBoxTemperature.Location = new System.Drawing.Point(32, 88);
        this.textBoxTemperature.Name = "textBoxTemperature";
        this.textBoxTemperature.Size = new System.Drawing.Size(400, 39);
        this.textBoxTemperature.TabIndex = 0;
        // 
        // comboBoxConversion
        // 
        this.comboBoxConversion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBoxConversion.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.comboBoxConversion.FormattingEnabled = true;
        this.comboBoxConversion.Items.AddRange(new object[] {
            "Цельсий → Фаренгейт",
            "Фаренгейт → Цельсий"});
        this.comboBoxConversion.Location = new System.Drawing.Point(32, 168);
        this.comboBoxConversion.Name = "comboBoxConversion";
        this.comboBoxConversion.Size = new System.Drawing.Size(400, 40);
        this.comboBoxConversion.TabIndex = 1;
        this.comboBoxConversion.SelectedIndexChanged += new System.EventHandler(this.comboBoxConversion_SelectedIndexChanged);
        // 
        // buttonConvert
        // 
        this.buttonConvert.BackColor = System.Drawing.Color.SkyBlue;
        this.buttonConvert.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.buttonConvert.Location = new System.Drawing.Point(32, 232);
        this.buttonConvert.Name = "buttonConvert";
        this.buttonConvert.Size = new System.Drawing.Size(400, 50);
        this.buttonConvert.TabIndex = 2;
        this.buttonConvert.Text = "Конвертировать";
        this.buttonConvert.UseVisualStyleBackColor = false;
        this.buttonConvert.Click += new System.EventHandler(this.buttonConvert_Click);
        // 
        // labelResult
        // 
        this.labelResult.BackColor = System.Drawing.Color.LightYellow;
        this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.labelResult.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.labelResult.Location = new System.Drawing.Point(32, 304);
        this.labelResult.Name = "labelResult";
        this.labelResult.Size = new System.Drawing.Size(400, 80);
        this.labelResult.TabIndex = 3;
        this.labelResult.Text = "Результат появится здесь";
        this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        // 
        // labelTemperature
        // 
        this.labelTemperature.AutoSize = true;
        this.labelTemperature.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelTemperature.Location = new System.Drawing.Point(32, 56);
        this.labelTemperature.Name = "labelTemperature";
        this.labelTemperature.Size = new System.Drawing.Size(163, 28);
        this.labelTemperature.TabIndex = 4;
        this.labelTemperature.Text = "Температура:";
        // 
        // labelConversion
        // 
        this.labelConversion.AutoSize = true;
        this.labelConversion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        this.labelConversion.Location = new System.Drawing.Point(32, 136);
        this.labelConversion.Name = "labelConversion";
        this.labelConversion.Size = new System.Drawing.Size(168, 28);
        this.labelConversion.TabIndex = 5;
        this.labelConversion.Text = "Тип конверсии:";
        // 
        // labelTitle
        // 
        this.labelTitle.AutoSize = true;
        this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
        this.labelTitle.Location = new System.Drawing.Point(32, 16);
        this.labelTitle.Name = "labelTitle";
        this.labelTitle.Size = new System.Drawing.Size(325, 37);
        this.labelTitle.TabIndex = 6;
        this.labelTitle.Text = "Конвертер температур";
        // 
        // Form1
        // 
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(482, 413);
        this.Controls.Add(this.labelTitle);
        this.Controls.Add(this.labelConversion);
        this.Controls.Add(this.labelTemperature);
        this.Controls.Add(this.labelResult);
        this.Controls.Add(this.buttonConvert);
        this.Controls.Add(this.comboBoxConversion);
        this.Controls.Add(this.textBoxTemperature);
        this.Name = "Form1";
        this.Text = "Конвертер температур";
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox textBoxTemperature;
    private System.Windows.Forms.ComboBox comboBoxConversion;
    private System.Windows.Forms.Button buttonConvert;
    private System.Windows.Forms.Label labelResult;
    private System.Windows.Forms.Label labelTemperature;
    private System.Windows.Forms.Label labelConversion;
    private System.Windows.Forms.Label labelTitle;
}