namespace TemperatureConverter;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
        comboBoxConversion.SelectedIndex = 0;
    }

    private void comboBoxConversion_SelectedIndexChanged(object sender, EventArgs e)
    {
        UpdateResultLabel();
    }

    private void UpdateResultLabel()
    {
        if (comboBoxConversion.SelectedIndex == -1)
            return;

        string placeholder = comboBoxConversion.SelectedIndex == 0 ? 
            "Введите температуру в °C" : "Введите температуру в °F";
        labelResult.Text = placeholder;
        labelResult.Font = new Font("Segoe UI", 12F, FontStyle.Regular);
    }

    private void buttonConvert_Click(object sender, EventArgs e)
    {
        if (!double.TryParse(textBoxTemperature.Text, out double inputTemp))
        {
            MessageBox.Show("Пожалуйста, введите корректное числовое значение температуры!", 
                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        double result;
        string resultText;

        if (comboBoxConversion.SelectedIndex == 0) // Цельсий → Фаренгейт
        {
            result = (inputTemp * 9 / 5) + 32;
            resultText = $"{inputTemp}°C = {result:F2}°F";
        }
        else // Фаренгейт → Цельсий
        {
            result = (inputTemp - 32) * 5 / 9;
            resultText = $"{inputTemp}°F = {result:F2}°C";
        }

        labelResult.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
        labelResult.Text = resultText;
    }
}