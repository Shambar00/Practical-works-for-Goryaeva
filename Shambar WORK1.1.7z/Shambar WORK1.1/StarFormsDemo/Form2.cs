using System;
using System.Drawing;
using System.Windows.Forms;

namespace StarFormsDemo
{
	public class Form2 : Form
	{
		private readonly FormStar mainForm;
		private readonly TextBox titleTextBox;
		private readonly TrackBar opacityTrack;
		private readonly Button applyTitleButton;
		private readonly Button closeButton;

		public Form2(FormStar mainForm)
		{
			this.mainForm = mainForm ?? throw new ArgumentNullException(nameof(mainForm));

			Text = "Form2 — взаимодействие";
			StartPosition = FormStartPosition.Manual;
			ClientSize = new Size(360, 180);
			FormBorderStyle = FormBorderStyle.FixedDialog;
			MaximizeBox = false;
			MinimizeBox = false;

			titleTextBox = new TextBox
			{
				Left = 16,
				Top = 16,
				Width = 320,
				Text = "Новый заголовок для звезды"
			};

			applyTitleButton = new Button
			{
				Text = "Применить заголовок",
				Left = 16,
				Top = 48,
				Width = 320
			};
			applyTitleButton.Click += (_, __) => mainForm.SetMainTitle(titleTextBox.Text);

			opacityTrack = new TrackBar
			{
				Left = 16,
				Top = 88,
				Width = 320,
				Minimum = 20,
				Maximum = 100,
				TickFrequency = 10,
				Value = (int)Math.Round(mainForm.Opacity * 100)
			};
			opacityTrack.Scroll += (_, __) => mainForm.SetMainOpacity(opacityTrack.Value / 100.0);

			closeButton = new Button
			{
				Text = "Закрыть",
				Left = 16,
				Top = 128,
				Width = 320
			};
			closeButton.Click += (_, __) => Hide();

			// При попытке закрыть крестиком — не уничтожать, а скрывать, сохраняя позицию
			FormClosing += (s, e) =>
			{
				if (e.CloseReason == CloseReason.UserClosing)
				{
					e.Cancel = true;
					Hide();
				}
			};

			Controls.Add(titleTextBox);
			Controls.Add(applyTitleButton);
			Controls.Add(opacityTrack);
			Controls.Add(closeButton);
		}
	}
}


