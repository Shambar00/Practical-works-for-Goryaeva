using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace StarFormsDemo
{
	public class FormStar : Form
	{
		private bool dragging = false;
		private Point dragCursorPoint;
		private Point dragFormPoint;

		private readonly Button openForm2Button;
		private Form2? form2Instance;
		private GraphicsPath? currentStarPath;

		public FormStar()
		{
			Text = "Фиолетовая звезда";
			ClientSize = new Size(480, 480);
			FormBorderStyle = FormBorderStyle.None;
			StartPosition = FormStartPosition.CenterScreen;
			DoubleBuffered = true;

			openForm2Button = new Button
			{
				Text = "Открыть Form2",
				AutoSize = true,
				BackColor = Color.White,
				ForeColor = Color.Black
			};
			openForm2Button.Click += (_, __) => ShowOrActivateForm2();
			Controls.Add(openForm2Button);

			MouseDown += Form1_MouseDown;
			MouseMove += Form1_MouseMove;
			MouseUp += Form1_MouseUp;

			SizeChanged += (_, __) => RebuildStarRegion();
			Paint += FormStar_Paint;
			Layout += (_, __) => PositionButton();

			RebuildStarRegion();
		}

		private void ShowOrActivateForm2()
		{
			if (form2Instance == null || form2Instance.IsDisposed)
			{
				form2Instance = new Form2(this) { ShowInTaskbar = false, StartPosition = FormStartPosition.Manual };
				// Первичное позиционирование — центр относительно звезды
				var x = Left + (Width - form2Instance.Width) / 2;
				var y = Top + (Height - form2Instance.Height) / 2;
				form2Instance.Location = new Point(Math.Max(0, x), Math.Max(0, y));
				form2Instance.Owner = this;
			}

			if (!form2Instance.Visible)
			{
				form2Instance.Opacity = 1.0; // на показ делаем видимой
				form2Instance.Show();
			}
			else
			{
				form2Instance.Activate();
			}
		}

		private void PositionButton()
		{
			openForm2Button.Left = (ClientSize.Width - openForm2Button.Width) / 2;
			openForm2Button.Top = (ClientSize.Height - openForm2Button.Height) / 2;
		}

		private void RebuildStarRegion()
		{
			currentStarPath?.Dispose();
			currentStarPath = BuildStarPath(new Rectangle(0, 0, ClientSize.Width, ClientSize.Height), 5, 0.5f);
			Region?.Dispose();
			Region = new Region(currentStarPath);
			Invalidate();
		}

		private void FormStar_Paint(object? sender, PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

			using (var violetBrush = new SolidBrush(Color.Violet))
			using (var outlinePen = new Pen(Color.MediumPurple, 2f))
			{
				if (currentStarPath != null)
				{
					e.Graphics.FillPath(violetBrush, currentStarPath);
					e.Graphics.DrawPath(outlinePen, currentStarPath);
				}
			}
		}

		private static GraphicsPath BuildStarPath(Rectangle bounds, int numPoints, float innerRadiusFactor)
		{
			var path = new GraphicsPath();

			int w = Math.Max(1, bounds.Width);
			int h = Math.Max(1, bounds.Height);

			float cx = bounds.X + w / 2f;
			float cy = bounds.Y + h / 2f;

			float outerRadius = Math.Min(w, h) / 2f - 2f;
			float innerRadius = outerRadius * innerRadiusFactor;

			double startAngle = -Math.PI / 2;
			double step = Math.PI / numPoints;

			PointF[] vertices = new PointF[numPoints * 2];
			for (int i = 0; i < vertices.Length; i++)
			{
				double angle = startAngle + i * step;
				float radius = (i % 2 == 0) ? outerRadius : innerRadius;

				float x = cx + (float)(Math.Cos(angle) * radius);
				float y = cy + (float)(Math.Sin(angle) * radius);
				vertices[i] = new PointF(x, y);
			}

			path.AddPolygon(vertices);
			path.CloseFigure();
			return path;
		}

		private void Form1_MouseDown(object? sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				dragging = true;
				dragCursorPoint = Cursor.Position;
				dragFormPoint = Location;
			}
			else if (e.Button == MouseButtons.Right)
			{
				Close();
			}
		}

		private void Form1_MouseMove(object? sender, MouseEventArgs e)
		{
			if (dragging)
			{
				Point delta = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
				Location = Point.Add(dragFormPoint, new Size(delta));
			}
		}

		private void Form1_MouseUp(object? sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				dragging = false;
			}
		}

		public void SetMainTitle(string title)
		{
			Text = title;
		}

		public void SetMainOpacity(double opacity01)
		{
			Opacity = Math.Max(0.2, Math.Min(1.0, opacity01));
		}
	}
}


